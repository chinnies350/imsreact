import React from "react";
const FormHelper = ({ content }) => {

  return (
    <small className="form-text text-muted">
      {content}
    </small>
  );
};

export default FormHelper;
