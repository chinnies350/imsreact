

var quizQuestions = [
    {
      question: "What franchise would you rather play a game from?",
      answerindex : 1,
      answers: [
        {
          type: "option1",
          content: "Halo",
          answer : false
        },
        {
          type: "option2",
          content: "Pokemon",
          answer : false
        },
        {
          type: "option3",
          content: "Uncharted1",
          answer : false
        },
        {
          type: "option4",
          content: "Uncharted2",
          answer : false
        }
      ]
    },
    {
      question: "Which console would you prefer to play with friends?",
      answerindex : 1,
      answers: [
        {
          type: "option1",
          content: "X-Box",
          answer : false
        },
        {
          type: "option2",
          content: "amdocs 64",
          answer : false
        },
        {
          type: "option3",
          content: "Playstation 100",
          answer : false
        },
        {
          type: "option4",
          content: "Playstation 1",
          answer : false
        }
      ]
    },
    {
      question: "Which of these racing franchises would you prefer to play a game from?",
      answerindex : 1,
      answers: [
        {
          type: "option1",
          content: "Forza",
          answer : false
        },
        {
          type: "option2",
          content: "Mario Kart",
          answer : false
        },
        {
          type: "option3",
          content: "Gran Turismo",
          answer : false
        },
        {
          type: "option4",
          content: "Playstation 1qq",
          answer : false
        }
      ]
    },
    {
      question: "Which of these games do you think is best?",
      answerindex : 1,
      answers: [
        {
          type: "option1",
          content: "BioShock",
          answer : false
        },
        {
          type: "option2",
          content: "The Legend of Zelda: Ocarina of Time",
          answer : false
        },
        {
          type: "option3",
          content: "Final Fantasy VII",
          answer : false
        },
        {
          type: "option4",
          content: "Playstation 1",
          answer : false
        }
      ]
    },
    {
      question: "What console would you prefer to own?",
      answerindex : 1,
      answers: [
        {
          type: "option1",
          content: "X-Box One",
          answer : false
        },
        {
          type: "option2",
          content: "Wii U",
          answer : false
        },
        {
          type: "option3",
          content: "Playstation 4",
          answer : false
        },
        {
          type: "option4",
          content: "Playstation11 1",
          answer : false
        }
      ]
    }
  ];
  
  export default quizQuestions;