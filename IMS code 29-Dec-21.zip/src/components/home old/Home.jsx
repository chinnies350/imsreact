
import React, { Fragment } from 'react';




class Home extends React.Component {
  componentDidMount() {
    
  }
  componentWillUnmount() {
   
  }
  render() {
    return (
        <Fragment>

        </Fragment>
    );
  }
}

export default Home;
