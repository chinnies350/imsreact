const baseUrl = "http://mean.prematix.solutions/ims/"; 
export const config = {
  baseUrl: baseUrl,
  LOG_LEVEL: 3,
  encryptKey: "e@#fgd%$Vr$EfedR(aswfW)Ef"
 
} 

